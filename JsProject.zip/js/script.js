   $('document').ready(function(){
    $('.imgs img').on('click',function(){
        $(this).addClass('act').siblings().removeClass('act') ;
        $('.imgs').css({opacity:'40%'})
        $('.mainImg').show()
        $('.mainImg').addClass('show');
        $('.mainImg img').hide().attr('src', $(this).attr('src')).fadeIn(1000);

         
          
    })

$('.next').on('click',function()
{
    if($('.imgs .act').is(':last-child'))
    {
        $('.imgs img').eq(0).click();
    }else{
    $('.imgs .act').next().click().fadeIn(1000);
}
})


$('.prev').on('click',function()
{
    if($('.imgs .act').is(':first-child'))
    {
        $('.imgs img:last').click()
    }else
    {
        $('.imgs .act').prev().click().fadeIn(1000);
    }
    
     
})      

$('.close').on('click',function()
{
    $('.mainImg').hide();
    $('.imgs').css({opacity:'100%'})
}
)

})
 

 